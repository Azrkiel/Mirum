
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  "Fortran"
  )
# The set of files for implicit dependencies of each language:
set(CMAKE_DEPENDS_CHECK_Fortran
  "/workspace/mirum-native/avl/src/aero.f" "/workspace/mirum-native/avl-build/src/CMakeFiles/avl.dir/aero.f.o"
  "/workspace/mirum-native/avl/src/aic.f" "/workspace/mirum-native/avl-build/src/CMakeFiles/avl.dir/aic.f.o"
  "/workspace/mirum-native/avl/src/ainput.f" "/workspace/mirum-native/avl-build/src/CMakeFiles/avl.dir/ainput.f.o"
  "/workspace/mirum-native/avl/src/airutil.f" "/workspace/mirum-native/avl-build/src/CMakeFiles/avl.dir/airutil.f.o"
  "/workspace/mirum-native/avl/src/amake.f" "/workspace/mirum-native/avl-build/src/CMakeFiles/avl.dir/amake.f.o"
  "/workspace/mirum-native/avl/src/amass.f" "/workspace/mirum-native/avl-build/src/CMakeFiles/avl.dir/amass.f.o"
  "/workspace/mirum-native/avl/src/amode.f" "/workspace/mirum-native/avl-build/src/CMakeFiles/avl.dir/amode.f.o"
  "/workspace/mirum-native/avl/src/aoper.f" "/workspace/mirum-native/avl-build/src/CMakeFiles/avl.dir/aoper.f.o"
  "/workspace/mirum-native/avl/src/aoutput.f" "/workspace/mirum-native/avl-build/src/CMakeFiles/avl.dir/aoutput.f.o"
  "/workspace/mirum-native/avl/src/aplotmd.f" "/workspace/mirum-native/avl-build/src/CMakeFiles/avl.dir/aplotmd.f.o"
  "/workspace/mirum-native/avl/src/aplottp.f" "/workspace/mirum-native/avl-build/src/CMakeFiles/avl.dir/aplottp.f.o"
  "/workspace/mirum-native/avl/src/aplotvl.f" "/workspace/mirum-native/avl-build/src/CMakeFiles/avl.dir/aplotvl.f.o"
  "/workspace/mirum-native/avl/src/arrow3d.f" "/workspace/mirum-native/avl-build/src/CMakeFiles/avl.dir/arrow3d.f.o"
  "/workspace/mirum-native/avl/src/asetup.f" "/workspace/mirum-native/avl-build/src/CMakeFiles/avl.dir/asetup.f.o"
  "/workspace/mirum-native/avl/src/atpforc.f" "/workspace/mirum-native/avl-build/src/CMakeFiles/avl.dir/atpforc.f.o"
  "/workspace/mirum-native/avl/src/atrim.f" "/workspace/mirum-native/avl-build/src/CMakeFiles/avl.dir/atrim.f.o"
  "/workspace/mirum-native/avl/src/autil.f" "/workspace/mirum-native/avl-build/src/CMakeFiles/avl.dir/autil.f.o"
  "/workspace/mirum-native/avl/src/avl.f" "/workspace/mirum-native/avl-build/src/CMakeFiles/avl.dir/avl.f.o"
  "/workspace/mirum-native/avl/src/cdcl.f" "/workspace/mirum-native/avl-build/src/CMakeFiles/avl.dir/cdcl.f.o"
  "/workspace/mirum-native/avl/src/getvm.f" "/workspace/mirum-native/avl-build/src/CMakeFiles/avl.dir/getvm.f.o"
  "/workspace/mirum-native/avl/src/hidden.f" "/workspace/mirum-native/avl-build/src/CMakeFiles/avl.dir/hidden.f.o"
  "/workspace/mirum-native/avl/src/limits.f" "/workspace/mirum-native/avl-build/src/CMakeFiles/avl.dir/limits.f.o"
  "/workspace/mirum-native/avl/src/matrix.f" "/workspace/mirum-native/avl-build/src/CMakeFiles/avl.dir/matrix.f.o"
  "/workspace/mirum-native/avl/src/plsubs.f" "/workspace/mirum-native/avl-build/src/CMakeFiles/avl.dir/plsubs.f.o"
  "/workspace/mirum-native/avl/src/pltops.f" "/workspace/mirum-native/avl-build/src/CMakeFiles/avl.dir/pltops.f.o"
  "/workspace/mirum-native/avl/src/plutil.f" "/workspace/mirum-native/avl-build/src/CMakeFiles/avl.dir/plutil.f.o"
  "/workspace/mirum-native/avl/src/second_g77.f" "/workspace/mirum-native/avl-build/src/CMakeFiles/avl.dir/second_g77.f.o"
  "/workspace/mirum-native/avl/src/sgutil.f" "/workspace/mirum-native/avl-build/src/CMakeFiles/avl.dir/sgutil.f.o"
  "/workspace/mirum-native/avl/src/spline.f" "/workspace/mirum-native/avl-build/src/CMakeFiles/avl.dir/spline.f.o"
  "/workspace/mirum-native/avl/src/userio.f" "/workspace/mirum-native/avl-build/src/CMakeFiles/avl.dir/userio.f.o"
  )
set(CMAKE_Fortran_COMPILER_ID "GNU")
set(CMAKE_Fortran_SUBMODULE_SEP "@")
set(CMAKE_Fortran_SUBMODULE_EXT ".smod")

# The include file search paths:
set(CMAKE_Fortran_TARGET_INCLUDE_PATH
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "" "src/avl" "gcc" "src/CMakeFiles/avl.dir/link.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  "/workspace/mirum-native/avl-build/plotlib/CMakeFiles/plt.dir/DependInfo.cmake"
  "/workspace/mirum-native/avl-build/eispack/CMakeFiles/eispack.dir/DependInfo.cmake"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  "/workspace/mirum-native/avl-build/eispack/CMakeFiles/eispack.dir/DependInfo.cmake"
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
