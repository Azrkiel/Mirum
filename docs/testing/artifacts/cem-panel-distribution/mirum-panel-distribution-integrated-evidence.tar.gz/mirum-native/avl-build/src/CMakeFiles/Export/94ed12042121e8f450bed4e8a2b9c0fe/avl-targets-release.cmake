#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "avl" for configuration "Release"
set_property(TARGET avl APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(avl PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/avl-3.32"
  )

list(APPEND _cmake_import_check_targets avl )
list(APPEND _cmake_import_check_files_for_avl "${_IMPORT_PREFIX}/bin/avl-3.32" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
