#############################################################################
#
#  AVL
#
#  Copyright (C) 2002 Mark Drela, Harold Youngren
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
#
#############################################################################


####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was avl-config.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../" ABSOLUTE)

####################################################################################

set(AVL_VERSION_MAJOR "3")
set(AVL_VERSION_MINOR "32")
set(AVL_VERSION "3.32")

set(AVL_FOUND TRUE)
set(AVL_EXECUTABLE "${PACKAGE_PREFIX_DIR}/bin/avl-3.32")

include("${CMAKE_CURRENT_LIST_DIR}/avl-targets.cmake")
