# CMake generated Testfile for 
# Source directory: /workspace/mirum-native/avl
# Build directory: /workspace/mirum-native/avl-build
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
subdirs("eispack")
subdirs("plotlib")
subdirs("src")
