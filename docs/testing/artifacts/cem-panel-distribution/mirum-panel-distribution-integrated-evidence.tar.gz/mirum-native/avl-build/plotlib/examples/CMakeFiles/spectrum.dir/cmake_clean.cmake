file(REMOVE_RECURSE
  "CMakeFiles/spectrum.dir/link.d"
  "CMakeFiles/spectrum.dir/spectrum.f.o"
  "spectrum"
  "spectrum.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang Fortran)
  include(CMakeFiles/spectrum.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
