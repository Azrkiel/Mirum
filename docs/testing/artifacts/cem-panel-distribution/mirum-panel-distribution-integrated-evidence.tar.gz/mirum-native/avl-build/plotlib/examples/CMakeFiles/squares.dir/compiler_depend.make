# Empty compiler generated dependencies file for squares.
# This may be replaced when dependencies are built.
