file(REMOVE_RECURSE
  "CMakeFiles/squaresdoublebuff.dir/link.d"
  "CMakeFiles/squaresdoublebuff.dir/squaresdoublebuff.f.o"
  "squaresdoublebuff"
  "squaresdoublebuff.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang Fortran)
  include(CMakeFiles/squaresdoublebuff.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
