# Empty compiler generated dependencies file for squaresdoublebuff.
# This may be replaced when dependencies are built.
