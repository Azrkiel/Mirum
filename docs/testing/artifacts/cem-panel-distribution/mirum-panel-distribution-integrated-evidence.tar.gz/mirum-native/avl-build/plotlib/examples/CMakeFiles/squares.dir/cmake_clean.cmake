file(REMOVE_RECURSE
  "CMakeFiles/squares.dir/link.d"
  "CMakeFiles/squares.dir/squares.f.o"
  "squares"
  "squares.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang Fortran)
  include(CMakeFiles/squares.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
