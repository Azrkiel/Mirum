file(REMOVE_RECURSE
  "CMakeFiles/symbols.dir/link.d"
  "CMakeFiles/symbols.dir/symbols.f.o"
  "symbols"
  "symbols.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang Fortran)
  include(CMakeFiles/symbols.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
