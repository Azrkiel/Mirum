
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  "Fortran"
  )
# The set of files for implicit dependencies of each language:
set(CMAKE_DEPENDS_CHECK_Fortran
  "/workspace/mirum-native/avl/plotlib/gw_subs.f" "/workspace/mirum-native/avl-build/plotlib/CMakeFiles/plt.dir/gw_subs.f.o"
  "/workspace/mirum-native/avl/plotlib/plt_base.f" "/workspace/mirum-native/avl-build/plotlib/CMakeFiles/plt.dir/plt_base.f.o"
  "/workspace/mirum-native/avl/plotlib/plt_color.f" "/workspace/mirum-native/avl-build/plotlib/CMakeFiles/plt.dir/plt_color.f.o"
  "/workspace/mirum-native/avl/plotlib/plt_font.f" "/workspace/mirum-native/avl-build/plotlib/CMakeFiles/plt.dir/plt_font.f.o"
  "/workspace/mirum-native/avl/plotlib/plt_util.f" "/workspace/mirum-native/avl-build/plotlib/CMakeFiles/plt.dir/plt_util.f.o"
  "/workspace/mirum-native/avl/plotlib/ps_subs.f" "/workspace/mirum-native/avl-build/plotlib/CMakeFiles/plt.dir/ps_subs.f.o"
  "/workspace/mirum-native/avl/plotlib/set_subs.f" "/workspace/mirum-native/avl-build/plotlib/CMakeFiles/plt.dir/set_subs.f.o"
  )
set(CMAKE_Fortran_COMPILER_ID "GNU")
set(CMAKE_Fortran_SUBMODULE_SEP "@")
set(CMAKE_Fortran_SUBMODULE_EXT ".smod")

# The include file search paths:
set(CMAKE_Fortran_TARGET_INCLUDE_PATH
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
