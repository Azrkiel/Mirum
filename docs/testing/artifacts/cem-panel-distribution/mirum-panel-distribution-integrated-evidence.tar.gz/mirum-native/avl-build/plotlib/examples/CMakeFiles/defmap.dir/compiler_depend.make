# Empty compiler generated dependencies file for defmap.
# This may be replaced when dependencies are built.
