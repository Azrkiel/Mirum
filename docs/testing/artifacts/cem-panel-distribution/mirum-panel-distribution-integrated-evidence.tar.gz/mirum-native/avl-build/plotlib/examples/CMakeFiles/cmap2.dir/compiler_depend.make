# Empty compiler generated dependencies file for cmap2.
# This may be replaced when dependencies are built.
