file(REMOVE_RECURSE
  "CMakeFiles/plt_font_test.dir/link.d"
  "CMakeFiles/plt_font_test.dir/test.f.o"
  "test"
  "test.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang Fortran)
  include(CMakeFiles/plt_font_test.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
