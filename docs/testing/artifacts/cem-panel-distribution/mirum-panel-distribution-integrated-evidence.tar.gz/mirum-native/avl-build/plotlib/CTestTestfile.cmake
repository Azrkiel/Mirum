# CMake generated Testfile for 
# Source directory: /workspace/mirum-native/avl/plotlib
# Build directory: /workspace/mirum-native/avl-build/plotlib
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
subdirs("examples")
subdirs("sym")
