file(REMOVE_RECURSE
  "libplt.a"
)
