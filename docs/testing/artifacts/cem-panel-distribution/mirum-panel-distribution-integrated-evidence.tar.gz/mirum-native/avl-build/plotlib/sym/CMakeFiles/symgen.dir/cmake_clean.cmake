file(REMOVE_RECURSE
  "CMakeFiles/symgen.dir/link.d"
  "CMakeFiles/symgen.dir/symgen.f.o"
  "symgen"
  "symgen.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang Fortran)
  include(CMakeFiles/symgen.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
