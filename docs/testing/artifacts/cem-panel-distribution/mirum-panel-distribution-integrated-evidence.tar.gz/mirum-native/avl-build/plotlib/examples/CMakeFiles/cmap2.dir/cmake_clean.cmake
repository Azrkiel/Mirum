file(REMOVE_RECURSE
  "CMakeFiles/cmap2.dir/link.d"
  "CMakeFiles/cmap2.dir/cmap2.f.o"
  "cmap2"
  "cmap2.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang Fortran)
  include(CMakeFiles/cmap2.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
