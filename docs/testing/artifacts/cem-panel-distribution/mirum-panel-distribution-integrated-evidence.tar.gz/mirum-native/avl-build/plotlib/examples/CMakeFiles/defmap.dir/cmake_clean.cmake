file(REMOVE_RECURSE
  "CMakeFiles/defmap.dir/link.d"
  "CMakeFiles/defmap.dir/defmap.f.o"
  "defmap"
  "defmap.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang Fortran)
  include(CMakeFiles/defmap.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
