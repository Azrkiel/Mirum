file(REMOVE_RECURSE
  "CMakeFiles/plt.dir/gw_subs.f.o"
  "CMakeFiles/plt.dir/plt_base.f.o"
  "CMakeFiles/plt.dir/plt_color.f.o"
  "CMakeFiles/plt.dir/plt_font.f.o"
  "CMakeFiles/plt.dir/plt_util.f.o"
  "CMakeFiles/plt.dir/ps_subs.f.o"
  "CMakeFiles/plt.dir/set_subs.f.o"
  "libplt.a"
  "libplt.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C Fortran)
  include(CMakeFiles/plt.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
