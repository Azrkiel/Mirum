# Empty compiler generated dependencies file for cmap3.
# This may be replaced when dependencies are built.
