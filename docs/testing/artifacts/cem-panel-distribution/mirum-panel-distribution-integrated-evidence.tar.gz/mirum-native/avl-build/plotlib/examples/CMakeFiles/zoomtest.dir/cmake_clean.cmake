file(REMOVE_RECURSE
  "CMakeFiles/zoomtest.dir/link.d"
  "CMakeFiles/zoomtest.dir/zoomtest.f.o"
  "zoomtest"
  "zoomtest.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang Fortran)
  include(CMakeFiles/zoomtest.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
