# Empty compiler generated dependencies file for zoomtest.
# This may be replaced when dependencies are built.
