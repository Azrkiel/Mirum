file(REMOVE_RECURSE
  "CMakeFiles/symbolsall.dir/link.d"
  "CMakeFiles/symbolsall.dir/symbolsall.f.o"
  "symbolsall"
  "symbolsall.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang Fortran)
  include(CMakeFiles/symbolsall.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
