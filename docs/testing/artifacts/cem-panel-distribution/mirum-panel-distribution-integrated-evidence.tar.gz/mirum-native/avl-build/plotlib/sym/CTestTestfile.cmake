# CMake generated Testfile for 
# Source directory: /workspace/mirum-native/avl/plotlib/sym
# Build directory: /workspace/mirum-native/avl-build/plotlib/sym
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test(plt_font_test "/workspace/mirum-native/avl-build/plotlib/sym/test")
set_tests_properties(plt_font_test PROPERTIES  _BACKTRACE_TRIPLES "/workspace/mirum-native/avl/plotlib/sym/CMakeLists.txt;30;add_test;/workspace/mirum-native/avl/plotlib/sym/CMakeLists.txt;0;")
