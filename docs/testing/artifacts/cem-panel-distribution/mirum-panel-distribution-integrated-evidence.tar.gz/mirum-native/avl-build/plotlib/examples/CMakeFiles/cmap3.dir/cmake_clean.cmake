file(REMOVE_RECURSE
  "CMakeFiles/cmap3.dir/link.d"
  "CMakeFiles/cmap3.dir/cmap3.f.o"
  "cmap3"
  "cmap3.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang Fortran)
  include(CMakeFiles/cmap3.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
