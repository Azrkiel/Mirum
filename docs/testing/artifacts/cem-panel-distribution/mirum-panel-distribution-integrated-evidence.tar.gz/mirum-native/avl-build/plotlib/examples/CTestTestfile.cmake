# CMake generated Testfile for 
# Source directory: /workspace/mirum-native/avl/plotlib/examples
# Build directory: /workspace/mirum-native/avl-build/plotlib/examples
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test(symbols "/workspace/mirum-native/avl-build/plotlib/examples/symbols")
set_tests_properties(symbols PROPERTIES  _BACKTRACE_TRIPLES "/workspace/mirum-native/avl/plotlib/examples/CMakeLists.txt;36;add_test;/workspace/mirum-native/avl/plotlib/examples/CMakeLists.txt;0;")
add_test(symbolsall "/workspace/mirum-native/avl-build/plotlib/examples/symbolsall")
set_tests_properties(symbolsall PROPERTIES  _BACKTRACE_TRIPLES "/workspace/mirum-native/avl/plotlib/examples/CMakeLists.txt;40;add_test;/workspace/mirum-native/avl/plotlib/examples/CMakeLists.txt;0;")
add_test(squares "/workspace/mirum-native/avl-build/plotlib/examples/squares")
set_tests_properties(squares PROPERTIES  _BACKTRACE_TRIPLES "/workspace/mirum-native/avl/plotlib/examples/CMakeLists.txt;44;add_test;/workspace/mirum-native/avl/plotlib/examples/CMakeLists.txt;0;")
add_test(squaresdoublebuff "/workspace/mirum-native/avl-build/plotlib/examples/squaresdoublebuff")
set_tests_properties(squaresdoublebuff PROPERTIES  _BACKTRACE_TRIPLES "/workspace/mirum-native/avl/plotlib/examples/CMakeLists.txt;48;add_test;/workspace/mirum-native/avl/plotlib/examples/CMakeLists.txt;0;")
add_test(spectrum "/workspace/mirum-native/avl-build/plotlib/examples/spectrum")
set_tests_properties(spectrum PROPERTIES  _BACKTRACE_TRIPLES "/workspace/mirum-native/avl/plotlib/examples/CMakeLists.txt;52;add_test;/workspace/mirum-native/avl/plotlib/examples/CMakeLists.txt;0;")
add_test(cmap2 "/workspace/mirum-native/avl-build/plotlib/examples/cmap2")
set_tests_properties(cmap2 PROPERTIES  _BACKTRACE_TRIPLES "/workspace/mirum-native/avl/plotlib/examples/CMakeLists.txt;56;add_test;/workspace/mirum-native/avl/plotlib/examples/CMakeLists.txt;0;")
add_test(cmap3 "/workspace/mirum-native/avl-build/plotlib/examples/cmap3")
set_tests_properties(cmap3 PROPERTIES  _BACKTRACE_TRIPLES "/workspace/mirum-native/avl/plotlib/examples/CMakeLists.txt;60;add_test;/workspace/mirum-native/avl/plotlib/examples/CMakeLists.txt;0;")
add_test(defmap "/workspace/mirum-native/avl-build/plotlib/examples/defmap")
set_tests_properties(defmap PROPERTIES  _BACKTRACE_TRIPLES "/workspace/mirum-native/avl/plotlib/examples/CMakeLists.txt;64;add_test;/workspace/mirum-native/avl/plotlib/examples/CMakeLists.txt;0;")
add_test(zoomtest "/workspace/mirum-native/avl-build/plotlib/examples/zoomtest")
set_tests_properties(zoomtest PROPERTIES  _BACKTRACE_TRIPLES "/workspace/mirum-native/avl/plotlib/examples/CMakeLists.txt;73;add_test;/workspace/mirum-native/avl/plotlib/examples/CMakeLists.txt;0;")
